#!/usr/bin/env python3
"""基础配置 CLI；路径不依赖调用者当前工作目录。"""
from pathlib import Path
import sys

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from spine_skin_tool.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
